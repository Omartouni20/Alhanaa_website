from django.apps import AppConfig


class AlhanaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alhana'
